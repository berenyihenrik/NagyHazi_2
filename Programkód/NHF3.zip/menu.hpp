#ifndef NAGYHAZI_2_MENU_H
#define NAGYHAZI_2_MENU_H
#include "vonat.hpp"
#include "jegy.hpp"

void menu(Jaratok& ja, Jegyek& je);

#endif

